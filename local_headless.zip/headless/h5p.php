<?php
require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // Course module ID

try {
    list($course, $cm) = get_course_and_cm_from_cmid($id, 'h5pactivity');
    require_login($course, true, $cm);

    $context = context_module::instance($cm->id);

    $fs = get_file_storage();
    $files = $fs->get_area_files($context->id, 'mod_h5pactivity', 'package', 0, 'id', false);
    if (empty($files)) {
        print_error('filenotfound');
    }
    $file = reset($files);
    $fileurl = moodle_url::make_pluginfile_url(
        $file->get_contextid(),
        $file->get_component(),
        $file->get_filearea(),
        $file->get_itemid(),
        $file->get_filepath(),
        $file->get_filename(),
        false
    );

    // Redirect to the core H5P player, but explicitly pass component=mod_h5pactivity
    // to enable the xAPI tracking and attempt saving.
    $embedurl = new moodle_url('/h5p/embed.php', [
        'url' => $fileurl->out(false),
        'component' => 'mod_h5pactivity'
    ]);

    redirect($embedurl);
} catch (Exception $e) {
    print_error('error', 'local_headless', '', $e->getMessage());
}
