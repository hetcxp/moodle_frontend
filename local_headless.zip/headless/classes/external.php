<?php
namespace local_headless;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;
use context_system;

defined('MOODLE_INTERNAL') || die();

class external extends external_api {

    public static function get_autologin_key_parameters() {
        return new external_function_parameters([]);
    }

    public static function get_autologin_key() {
        global $USER, $CFG;

        $context = context_system::instance();
        self::validate_context($context);

        require_once($CFG->libdir . '/moodlelib.php');

        // Borrar keys anteriores del mismo usuario para evitar conflictos
        delete_user_key('tool_mobile', $USER->id);

        // Crear key nueva con IP restriction y TTL de 1 minuto (igual que el core mobile)
        $iprestriction = getremoteaddr();
        $validuntil    = time() + 60;
        $key = create_user_key('tool_mobile', $USER->id, null, $iprestriction, $validuntil);

        $autologinurl = $CFG->wwwroot . '/local/headless/autologin.php';

        return [
            'key'          => $key,
            'autologinurl' => $autologinurl,
        ];
    }

    public static function get_autologin_key_returns() {
        return new external_single_structure([
            'key'          => new external_value(PARAM_ALPHANUMEXT, 'Auto-login key'),
            'autologinurl' => new external_value(PARAM_URL, 'Auto-login URL'),
        ]);
    }
}
